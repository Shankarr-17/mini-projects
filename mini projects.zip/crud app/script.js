document.getElementById("addTaskBtn").addEventListener("click", addTask);

function addTask() {
    const taskInput = document.getElementById("taskInput");
    const taskText = taskInput.value.trim();

    if (taskText === "") {
        alert("Please enter a task");
        return;
    }

    const taskList = document.getElementById("taskList");
    
    // Create a new task item (li)
    const li = document.createElement("li");

    // Create a text input to allow task editing
    const taskTextElement = document.createElement("input");
    taskTextElement.type = "text";
    taskTextElement.value = taskText;
    taskTextElement.setAttribute("readonly", "readonly");

    // Add Edit and Delete buttons
    const editBtn = document.createElement("button");
    editBtn.innerText = "Edit";
    editBtn.classList.add("edit-btn");

    const deleteBtn = document.createElement("button");
    deleteBtn.innerText = "Delete";
    deleteBtn.classList.add("delete-btn");

    // Add event listeners for buttons
    editBtn.addEventListener("click", function () {
        if (editBtn.innerText === "Edit") {
            taskTextElement.removeAttribute("readonly");
            taskTextElement.focus();
            editBtn.innerText = "Save";
        } else {
            taskTextElement.setAttribute("readonly", "readonly");
            editBtn.innerText = "Edit";
        }
    });

    deleteBtn.addEventListener("click", function () {
        taskList.removeChild(li);
    });

    li.appendChild(taskTextElement);
    li.appendChild(editBtn);
    li.appendChild(deleteBtn);

    taskList.appendChild(li);

    // Clear input field after adding the task
    taskInput.value = "";
}

// Optional: Add task by pressing Enter
document.getElementById("taskInput").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        addTask();
    }
});
