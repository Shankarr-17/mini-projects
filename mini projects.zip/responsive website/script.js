document.querySelectorAll('.read-more').forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        alert('Read more about this blog post coming soon!');
    });
});
