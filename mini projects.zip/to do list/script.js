// Function to add a new task
document.getElementById("addTaskBtn").addEventListener("click", function() {
    const taskInput = document.getElementById("taskInput");
    const taskText = taskInput.value.trim();

    if (taskText) {
        addTask(taskText);
        taskInput.value = ""; // Clear the input field
    }
});

// Function to create a new task element
function addTask(taskText) {
    const taskList = document.getElementById("taskList");

    const li = document.createElement("li");
    li.innerText = taskText;

    // Complete button
    const completeBtn = document.createElement("button");
    completeBtn.innerText = "Complete";
    completeBtn.classList.add("complete-btn");
    completeBtn.onclick = function() {
        li.classList.toggle("completed");
    };

    // Delete button
    const deleteBtn = document.createElement("button");
    deleteBtn.innerText = "Delete";
    deleteBtn.onclick = function() {
        taskList.removeChild(li);
    };

    li.appendChild(completeBtn);
    li.appendChild(deleteBtn);

    taskList.appendChild(li);
}

// Optional: Add tasks by pressing "Enter"
document.getElementById("taskInput").addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        document.getElementById("addTaskBtn").click();
    }
});
