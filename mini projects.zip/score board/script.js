// Initial scores
let scoreA = 0;
let scoreB = 0;

// Increment the score of a team
function increment(team) {
    if (team === 'A') {
        scoreA++;
        document.getElementById('scoreA').innerText = scoreA;
    } else if (team === 'B') {
        scoreB++;
        document.getElementById('scoreB').innerText = scoreB;
    }
}

// Decrement the score of a team
function decrement(team) {
    if (team === 'A') {
        if (scoreA > 0) {
            scoreA--;
            document.getElementById('scoreA').innerText = scoreA;
        }
    } else if (team === 'B') {
        if (scoreB > 0) {
            scoreB--;
            document.getElementById('scoreB').innerText = scoreB;
        }
    }
}

// Reset the scores
function resetScores() {
    scoreA = 0;
    scoreB = 0;
    document.getElementById('scoreA').innerText = scoreA;
    document.getElementById('scoreB').innerText = scoreB;
}
